package com.library.aspect;

import org.aspectj.lang.ProceedingJoinPoint;

public class LoggingAspect {

	
		public Object logExecutionTime(ProceedingJoinPoint joinPoint) throws Throwable{
			Object proceed = joinPoint.proceed();
			long start = System.currentTimeMillis();
	        long executionTime = System.currentTimeMillis() - start;
	        System.out.println(joinPoint.getSignature() + " executed in " + executionTime + "ms");
			return proceed;
		}
}
