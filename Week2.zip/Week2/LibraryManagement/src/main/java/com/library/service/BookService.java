package com.library.service;

import com.library.repository.BookRepository;

public class BookService {
	/* To test the configuration for Exercise-1
	 * BookService(){ System.out.println("Book Service Constructor triggered"); }
	 */
	BookRepository bookRepository;
	
	public void setBookRepository(BookRepository bookRepository) {
		this.bookRepository = bookRepository;
	}
	
	public void printBookDetails()
	{
		bookRepository.printBookDetails();
	}
	
}
