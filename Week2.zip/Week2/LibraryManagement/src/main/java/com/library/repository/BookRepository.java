package com.library.repository;

public class BookRepository {
	public void printBookDetails() {
		System.out.println("Printing Book Details: BookRepository");
	}
}
