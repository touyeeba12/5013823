package com.library1.LibraryManagement1;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.library1.repository.BookRepository;
import com.library1.service.BookService;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	
    	//to load the Spring context and test the configuration. exercise - 5
		  ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		  
		  BookService bookService1 = context.getBean(BookService.class);
		  bookService1.printBookDetails();
		
		 // to test the annotation based component scan - exercise - 6
		  context.getBean(BookService.class);
		  context.getBean(BookRepository.class);
		 
		 
	  	//testing constructor and setter Injection Exercise - 7
		  BookService bookService2 = context.getBean(BookService.class);
		  bookService2.printBookDetails();
	 
    	
    }
}
