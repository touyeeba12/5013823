package com.library1.service;


import org.springframework.stereotype.Service;

import com.library1.repository.BookRepository;

@Service
public class BookService {
	BookRepository bookRepo;
	
	public BookService()
	{
//		to verify the annotation based Component Scanning - Exercise - 6
		System.out.println("Book Service Constructor Triggered");
	}
	
	public BookService(BookRepository bookRepo) {
		this.bookRepo = bookRepo;
	}

	public void setBookRepo(BookRepository bookRepo) {
		this.bookRepo = bookRepo;
	}
	
	public void printBookDetails()
	{
		bookRepo.printBookDetails();
	}
}
