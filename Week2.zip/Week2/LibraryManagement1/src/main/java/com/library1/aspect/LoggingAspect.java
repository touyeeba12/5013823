package com.library1.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

//implementing basic aop with spring - Exercise-8
@Aspect
@Component
public class LoggingAspect {
	
	@Before("execution(* com.library1.service.BookService.*(..))")
	public void logBefore()
	{
		System.out.println("Executing logBefore Method");
	}
	
	@After("execution(* com.library1.service.BookService.*(..))")
	public void logAfter()
	{
		System.out.println("Executing logAfter Method");
	}
}
