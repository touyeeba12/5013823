package com.library1.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
	
	public BookRepository(){
		//to test the annotation based component scan - Exercise - 6
		System.out.println("Book Repository Constructor triggered");
	}
	public void printBookDetails()
	{
		System.out.println("Printing book details : Book Repository");
	}
}
