package com.BookStore.BookStoreAPI.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookStore.BookStoreAPI.model.Book;
import com.BookStore.BookStoreAPI.repository.BookRepository;

@Service
public class BookService {
	
	@Autowired
	BookRepository repository;

	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	public void createBook(Book book) {
		// TODO Auto-generated method stub
		
		repository.save(book);
		
	}

	public void updateBook(Long id, Book updatedBook) {
		// TODO Auto-generated method stub
		if(repository.findById(id) == null)
			System.out.println("Book Not found");
		else
			repository.deleteById(id);
			repository.save(updatedBook);
	}

	public void deleteBook(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	public Book getBookById(Long id) {
		// TODO Auto-generated method stub
		return (Book) repository.findById(id).get();
	}
	
	public List<Book> getBooksByTitle(String title){
		return repository.findByTitleContainingIgnoreCase(title);
	}

	
	public List<Book> getBooksByAuthor(String author)
	{
		return repository.findByAuthorContainingIgnoreCase(author);
	}
}
