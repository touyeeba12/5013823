package com.BookStore.BookStoreAPI.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.BookStore.BookStoreAPI.model.Customer;
import com.BookStore.BookStoreAPI.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	CustomerService service;
	
	@PostMapping
	public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
        Customer createdCustomer = service.createCustomer(customer);
        return ResponseEntity.ok(createdCustomer);
    }
	
	 @PostMapping("/register")
	    public ResponseEntity<Customer> registerCustomer(
	            @RequestParam String name,
	            @RequestParam String email,
	            @RequestParam String password) {

	        Customer customer = new Customer();
	        customer.setName(name);
	        customer.setEmail(email);
	        customer.setPassword(password);

	        Customer createdCustomer = service.createCustomer(customer);

	        return ResponseEntity.ok(createdCustomer);
	    }

}
