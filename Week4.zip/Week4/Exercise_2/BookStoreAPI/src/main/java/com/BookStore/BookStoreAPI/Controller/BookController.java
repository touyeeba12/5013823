package com.BookStore.BookStoreAPI.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.BookStore.BookStoreAPI.service.BookService;

import com.BookStore.BookStoreAPI.model.Book;

@RestController
@RequestMapping("/books")
public class BookController {
	@Autowired
	BookService service;
	
	@GetMapping
	public List<Book> getAllBooks(){
		return service.getAllBooks();
	}
	
	@GetMapping("/{id}")
	public Book getBookById(@PathVariable Long id)
	{
		return service.getBookById(id);
	}
	
	@PostMapping
	public void createBook(@RequestBody Book book)
	{
		service.createBook(book);
	}
	
	@PutMapping("/{id}")
	public void updateBook(@PathVariable Long id,@RequestBody Book updatedBook)
	{
		service.updateBook(id,updatedBook);
	}
	
	
	@DeleteMapping("/{id}")
	public void deleteBook(@PathVariable Long id)
	{
		service.deleteBook(id);
	}
}
