package com.BookStore.BookStoreAPI.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.BookStore.BookStoreAPI.dto.CustomerDTO;
import com.BookStore.BookStoreAPI.model.Customer;

@Mapper
public interface CustomerMapper {
    CustomerMapper INSTANCE = Mappers.getMapper(CustomerMapper.class);
    
    CustomerDTO toDTO(Customer customer);
    Customer toEntity(CustomerDTO customerDTO);
}
