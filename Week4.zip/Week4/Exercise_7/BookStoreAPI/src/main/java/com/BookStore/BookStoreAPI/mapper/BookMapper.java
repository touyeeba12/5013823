package com.BookStore.BookStoreAPI.mapper;



import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.BookStore.BookStoreAPI.dto.BookDTO;
import com.BookStore.BookStoreAPI.model.Book;

@Mapper
public interface BookMapper {
    BookMapper INSTANCE = Mappers.getMapper(BookMapper.class);
    
    BookDTO toDTO(Book book);
    Book toEntity(BookDTO bookDTO);
}
