package com.week3.EmployeeManagementSystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.week3.EmployeeManagementSystem.model.Department;

@Repository
public interface DepartementRepository extends JpaRepository<Department,Long>{
	
	Department findByName(String name);
	

}
