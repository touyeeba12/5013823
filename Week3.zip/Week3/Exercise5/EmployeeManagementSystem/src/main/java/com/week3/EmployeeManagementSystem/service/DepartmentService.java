package com.week3.EmployeeManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.week3.EmployeeManagementSystem.model.Department;
import com.week3.EmployeeManagementSystem.repository.DepartementRepository;

@Service
public class DepartmentService {
	@Autowired
	private DepartementRepository departmentRepo;
	
	
	//Create
	public void addDepartment(Department dept) {
		 departmentRepo.save(dept);
	}
	
	//Read
	public List<Department> getAllDepartments(){
		return departmentRepo.findAll();
	}
	
	public Department getDeptById(long id)
	{
		return departmentRepo.findById(id).get();
	}
	
	//update
	public void updateDepartment(Department dept)
	{
		departmentRepo.save(dept);
	}
	
	//delete
	public void deleteDepartment(long id)
	{
		departmentRepo.deleteById(id);
	}
	
	public Department getDeptByName(String name)
	{
		return departmentRepo.findByName(name);
	}
}
