package com.week3.EmployeeManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.week3.EmployeeManagementSystem.model.Employee;
import com.week3.EmployeeManagementSystem.repository.EmployeeRepository;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service
public class EmployeeService {

		@Autowired
		private EmployeeRepository employeeRepo;
		
		
		//Create
		public void addEmployee(Employee employee) {
			 employeeRepo.save(employee);
		}
		
		//Read
		public List<Employee> getAllEmployees(){
			return employeeRepo.findAll();
		}
		
		public Employee getEmployeeById(long id)
		{
			return employeeRepo.findById(id).get();
		}
		
		//update
		public void updateEmployee(Employee employee)
		{
			employeeRepo.save(employee);
		}
		
		public void deleteEmployee(long id)
		{
			employeeRepo.deleteById(id);
		}
		
		
		//implementing batch processing using service methods
	    @PersistenceContext
	    private EntityManager entityManager;

	    @Transactional
	    public void batchInsertEmployees(List<Employee> employees) {
	        final int batchSize = 30;
	        for (int i = 0; i < employees.size(); i++) {
	            entityManager.persist(employees.get(i));
	            if (i % batchSize == 0 && i > 0) {
	                // Flush and clear the persistence context to prevent memory issues
	                entityManager.flush();
	                entityManager.clear();
	            }
	        }
	    }

		
}
