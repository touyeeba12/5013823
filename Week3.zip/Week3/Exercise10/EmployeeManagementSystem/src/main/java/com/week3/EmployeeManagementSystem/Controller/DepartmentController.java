package com.week3.EmployeeManagementSystem.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.week3.EmployeeManagementSystem.model.Department;
import com.week3.EmployeeManagementSystem.service.DepartmentService;


@RestController
@RequestMapping("/api/department")
public class DepartmentController {
	@Autowired
	private DepartmentService service;
	
	//create
	@PostMapping
	public void addDepartment(@RequestBody Department dept)
	{
		service.addDepartment(dept);
	}
	
	//read
	@GetMapping
	public List<Department> getAllDepartments(){
		return service.getAllDepartments();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Department> getDeptById(@PathVariable long id)
	{
		Department dept = service.getDeptById(id);
		
		if(dept == null)
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<>(dept,HttpStatus.OK);
	}
	
	
	@PutMapping("/{id}")
	public void updateDepartment(@RequestBody Department department)
	{
		service.updateDepartment(department);
	}
	
	@DeleteMapping("/{id}")
	public void deleteDepartment(@PathVariable long id)
	{
		service.deleteDepartment(id);
	}
	
}
