package com.week3.EmployeeManagementSystem.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class Controller {
	
	
	@RequestMapping("/")
	public String greet()
	{
		return "For testing";
	}
	
}




