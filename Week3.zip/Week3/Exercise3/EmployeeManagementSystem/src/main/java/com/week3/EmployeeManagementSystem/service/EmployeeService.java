package com.week3.EmployeeManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.week3.EmployeeManagementSystem.model.Employee;
import com.week3.EmployeeManagementSystem.repository.EmployeeRepository;

@Service
public class EmployeeService {

		@Autowired
		private EmployeeRepository employeeRepo;
		
		public List<Employee> getAllEmployees(){
			return employeeRepo.findAll();
		}
		
		public Employee addEmployee(Employee employee) {
			return employeeRepo.save(employee);
		}
		
}
