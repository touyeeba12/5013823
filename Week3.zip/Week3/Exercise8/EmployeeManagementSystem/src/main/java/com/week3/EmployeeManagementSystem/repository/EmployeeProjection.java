package com.week3.EmployeeManagementSystem.repository;

import org.springframework.beans.factory.annotation.Value;
//interface based projection
public interface EmployeeProjection {
	 @Value("#{target.id}")
	    Long getId();

    @Value("#{target.name}")
    String getName();

    @Value("#{target.email}")
    String getEmail();
    interface DepartmentProjection {
        @Value("#{target.id}")
        Long getId();

        @Value("#{target.name}")
        String getName();
    }
}
