package com.week3.EmployeeManagementSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.week3.EmployeeManagementSystem.dto.DepartmentDto;
import com.week3.EmployeeManagementSystem.model.Department;

@Repository
public interface DepartementRepository extends JpaRepository<Department,Long>{
	
	Department findByName(String name);
	
	
	@Query("SELECT new com.week3.EmployeeManagementSystem.dto.DepartmentDto(d.id, d.name) FROM Department d")
    List<DepartmentDto> findAllDepartmentDtos();

}
