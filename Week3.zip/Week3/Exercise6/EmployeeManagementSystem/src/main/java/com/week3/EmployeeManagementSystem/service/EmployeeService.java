package com.week3.EmployeeManagementSystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.week3.EmployeeManagementSystem.model.Department;
import com.week3.EmployeeManagementSystem.model.Employee;
import com.week3.EmployeeManagementSystem.repository.EmployeeRepository;

@Service
public class EmployeeService {

		@Autowired
		private EmployeeRepository employeeRepo;
		
		
		//Create
		public void addEmployee(Employee employee) {
			 employeeRepo.save(employee);
		}
		
		//Read
		public List<Employee> getAllEmployees(){
			return employeeRepo.findAll();
		}
		
		public Employee getEmployeeById(long id)
		{
			return employeeRepo.findById(id).get();
		}
		
		public List<Employee> getEmployeeByName(String name)
		{
			return employeeRepo.findByName(name);
		}
		
		public List<Employee> getAllEmployeesByNameDesc()
		{
			return employeeRepo.findAllOrderedByNameDescending();
		}
		
		public List<Employee> getEmployeeByDept(String dept)
		{
			return employeeRepo.findEmployeesByDepartment(dept);
		}
		//update
		public void updateEmployee(Employee employee)
		{
			employeeRepo.save(employee);
		}
		
		public void deleteEmployee(long id)
		{
			employeeRepo.deleteById(id);
		}

		public Page<Employee> getAllEmployees(int page,int size,String sortBy) {
			
			Pageable pageable = PageRequest.of(page, size, Sort.by(sortBy));
			return employeeRepo.findAll(pageable);
		}
		
}
