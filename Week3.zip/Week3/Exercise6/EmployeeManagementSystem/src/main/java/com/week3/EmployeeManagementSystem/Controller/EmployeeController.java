package com.week3.EmployeeManagementSystem.Controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.week3.EmployeeManagementSystem.model.Employee;
import com.week3.EmployeeManagementSystem.service.EmployeeService;

@RestController
@RequestMapping("/api/employee")
public class EmployeeController {

		@Autowired
		private EmployeeService service;
		
		//create
		@PostMapping
		public void addEmployee(@RequestBody Employee employee)
		{
			service.addEmployee(employee);
		}
		
		//read
		/*
		 * @GetMapping public List<Employee> getAllEmployees(){ return
		 * service.getAllEmployees(); }
		 */
		@GetMapping
	    public Page<Employee> getAllEmployees(
	        @RequestParam(defaultValue = "0") int page,
	        @RequestParam(defaultValue = "10") int size,
	        @RequestParam(defaultValue = "id") String sortBy) {
	        
	        
	        return service.getAllEmployees(page, size,sortBy);
	    }

		
		@GetMapping("/{id}")
		public ResponseEntity<Employee> getEmployeeById(@PathVariable long id)
		{
			Employee emp = service.getEmployeeById(id);
			
			if(emp == null)
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
			else
				return new ResponseEntity<>(emp,HttpStatus.OK);
		}
		
		
		
		  @GetMapping("/name/{name}") public List<Employee>
		  getEmployeesByName(@PathVariable String name){ return
		  service.getEmployeeByName(name); }
		  
		  @GetMapping("/dept/{dept}") public List<Employee>
		  getEmployeesByDept(@PathVariable String dept){ return
		  service.getEmployeeByDept(dept); }
		  
		  @GetMapping("/names/sort") public List<Employee> getEmployeesByNameDesc(){
		  return service.getAllEmployeesByNameDesc(); }
		 
		
		
		
		@PutMapping("/{id}")
		public void updateEmployee(@RequestBody Employee employee)
		{
			service.updateEmployee(employee);
		}
		
		@DeleteMapping("/{id}")
		public void deleteEmployee(@PathVariable long id)
		{
			service.deleteEmployee(id);
		}
		
}
