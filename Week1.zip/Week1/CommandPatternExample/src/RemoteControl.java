
public class RemoteControl {
	Command command;
	void setCommand(Command command)
	{
		this.command = command;
	}
	public void executeCommand()
	{
		command.execute();
	}
	
}
