
public class Light {
	void turnOn()
	{
		System.out.println("Lights turned On");
	}
	void turnOff()
	{
		System.out.println("Lights turned Off");
	}
}	
