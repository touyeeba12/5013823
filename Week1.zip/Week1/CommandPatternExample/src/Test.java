
public class Test {
	public static void main(String args[]) {
		Light light = new Light();
		Command lightOn = new LightOnCommand(light);
		Command lightOff = new  LightOffCommand(light);
		RemoteControl btn1 = new RemoteControl();
		btn1.setCommand(lightOn);
		btn1.executeCommand();
		RemoteControl btn2 = new RemoteControl();
		btn2.setCommand(lightOff);
		btn2.executeCommand();
	}
}
