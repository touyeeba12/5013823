
public interface ExcelDocument extends Document{
	
}
