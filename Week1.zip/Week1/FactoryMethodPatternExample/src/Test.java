
public class Test {

	public static void main(String[] args) {
		DocumentFactory excelObj = new ConcreteFactoryExcel();
		Document excelDoc = excelObj.createDocument();
		excelDoc.write();
		
		DocumentFactory wordObj = new ConcreteFactoryWord();
		Document wordDoc = wordObj.createDocument();
		wordDoc.write();
		
		DocumentFactory pdfObj = new ConcreteFactoryPDF();
		Document pdfDoc = pdfObj.createDocument();
		pdfDoc.write();
	}

}
