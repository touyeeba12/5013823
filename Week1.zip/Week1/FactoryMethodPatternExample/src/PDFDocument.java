
public interface PDFDocument extends Document {

}
