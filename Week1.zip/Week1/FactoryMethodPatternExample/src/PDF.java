
public class PDF implements PDFDocument {

	@Override
	public void write() {
		System.out.println("Writing in a PDF Document");

	}

}
