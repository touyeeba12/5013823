
public class ConcreteFactoryPDF extends DocumentFactory{

	@Override
	public Document createDocument() {
		
		return new PDF();
	}

}
