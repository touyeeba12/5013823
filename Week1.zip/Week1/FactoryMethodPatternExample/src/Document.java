
public interface Document {
	void write();
}
