
public class ConcreteFactoryWord extends DocumentFactory{

	@Override
	public Document createDocument() {
		return new Word();
	}

}
