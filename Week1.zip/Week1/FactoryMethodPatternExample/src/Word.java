
public class Word implements WordDocument {

	@Override
	public void write() {
		
		System.out.println("Writing in a Word Document");

	}

}
