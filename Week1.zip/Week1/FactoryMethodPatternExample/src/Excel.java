
public class Excel implements ExcelDocument{
	public void write()
	{
		System.out.println("Writing in a Excel Document");
	}
}
