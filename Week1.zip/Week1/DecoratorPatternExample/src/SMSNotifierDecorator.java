
public class SMSNotifierDecorator extends NotifierDecorator{
	
	SMSNotifierDecorator(Notifier obj) {
		super(obj);
	}

	public void send()
	{
		super.send();
		System.out.println("Sending Message via SMS");
	}
}
