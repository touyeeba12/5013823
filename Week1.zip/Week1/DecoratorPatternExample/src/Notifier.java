
public interface Notifier {
	void send();
}
