
public abstract class NotifierDecorator implements Notifier{
	protected Notifier obj;
	NotifierDecorator(Notifier obj)
	{
		this.obj = obj;
	}
	public void send() {
		obj.send();
	}
	
}
