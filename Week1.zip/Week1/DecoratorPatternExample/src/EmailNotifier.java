
public class EmailNotifier implements Notifier{
	public void send()
	{
		System.out.println("Sending Message via E-mail");
	}
}
