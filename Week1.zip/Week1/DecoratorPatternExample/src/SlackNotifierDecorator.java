
public class SlackNotifierDecorator extends NotifierDecorator {

	SlackNotifierDecorator(Notifier obj) {
		super(obj);
	}

	public void send() {
		super.send();
		System.out.println("Sending Message via Slack");
	}
	
	
}
