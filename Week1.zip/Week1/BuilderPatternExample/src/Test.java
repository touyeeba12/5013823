
public class Test {
	public static void main(String[] args) {
		Computer obj1 = Computer.Builder.newInstance().setRAM(8).setStorage(1000).build();
		Computer obj2 = Computer.Builder.newInstance().setRAM(16).setCPU(2).setStorage(2000).build();
		System.out.println(obj1);
		System.out.println(obj2);
		
	}
}
