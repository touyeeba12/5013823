
public class Computer {
	private int storage;
	private int RAM;
	private int CPU;
	private Computer(Builder builder)
	{
		this.storage = builder.storage;
		this.RAM = builder.RAM;
		this.CPU = builder.CPU;
	}
	public String toString()
	{
		return(storage+" "+RAM+" "+CPU);
	}
	static class Builder{
		
		private int storage;
		private int CPU;
		private int RAM;
		
		public static Builder newInstance()
		{
			return new Builder();
		}
		private Builder() {};
		public Builder setStorage(int storage)
		{
			this.storage = storage;
			return this;
		}
		public Builder setCPU(int CPU)
		{
			this.CPU = CPU;
			return this;
		}
		public Builder setRAM(int RAM)
		{
			this.RAM = RAM;
			return this;
		}
		public Computer build()
		{
			return new Computer(this);
		}
		
	}
}
