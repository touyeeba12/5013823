
public interface PaymentStrategy {
	void pay();
}
