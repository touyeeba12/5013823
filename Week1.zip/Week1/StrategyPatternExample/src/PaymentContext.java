
public class PaymentContext {
	PaymentStrategy strategy;
	PaymentContext(PaymentStrategy strategy)
	{
		this.strategy = strategy;
	}
	void  makePayment() {
		strategy.pay();
	}
}
