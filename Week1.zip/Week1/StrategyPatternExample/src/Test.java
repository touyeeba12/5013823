
public class Test {

	public static void main(String[] args) {
		PaymentStrategy creditCard = new CreditCardPayment();
		PaymentContext context1 = new PaymentContext(creditCard);
		context1.makePayment();
		
		PaymentStrategy payPal = new PayPalPayment();
		PaymentContext context2 = new PaymentContext(payPal);
		context2.makePayment();

	}

}
