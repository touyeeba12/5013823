
public class PaypalAdapter implements PaymentProcessor{
	PaypalGateway paypal;
	PaypalAdapter(PaypalGateway paypal)
	{
		this.paypal = paypal;
	}
	public void processPayment() {
		paypal.payment();
	}
}
