
public class PaypalGateway {
	
	public void payment() {
		System.out.println("Making Payment using PaypalGateway");
	}
}
