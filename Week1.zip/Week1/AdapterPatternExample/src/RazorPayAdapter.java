
public class RazorPayAdapter implements PaymentProcessor{
	RazorPayGateway razorpay;
	RazorPayAdapter(RazorPayGateway razorpay)
	{
		this.razorpay = razorpay;
	}
	public void processPayment()
	{
		razorpay.payment();
	}
}
