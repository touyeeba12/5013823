
public class RazorPayGateway {
	
	public void payment() {
		System.out.println("Making Payment using RazorPay Gateway");
	}
}
