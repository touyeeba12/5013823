
public class Test {

	public static void main(String[] args) {
		PaypalGateway pp = new PaypalGateway();
		RazorPayGateway rp = new RazorPayGateway();
		
		PaymentProcessor p1 = new PaypalAdapter(pp);
		PaymentProcessor p2  = new RazorPayAdapter(rp);
		
		p1.processPayment();
		p2.processPayment();
	}

}
