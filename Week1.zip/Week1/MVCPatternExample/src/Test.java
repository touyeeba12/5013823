
public class Test {

	public static void main(String[] args) {
		Student model = new Student();
		StudentView view = new StudentView();
		
		StudentController controller = new StudentController(model,view);
		
		controller.addDetails("Sname", "Sid", (float)9.0);
		
		controller.updateDetails();

	}

}
