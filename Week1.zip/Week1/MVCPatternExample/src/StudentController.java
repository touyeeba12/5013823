
public class StudentController {
	private Student model;
	private StudentView view;
	
	StudentController(Student model,StudentView view)
	{
		this.model = model;
		this.view = view;
	}
	
	void addDetails(String name,String id, float grade)
	{
		model.setName(name);
		model.setId(id);
		model.setGrade(grade);
	}
	void updateDetails()
	{
		view.displayStudentDetails(model.getName(),model.getId(),model.getGrade());
	}
}
