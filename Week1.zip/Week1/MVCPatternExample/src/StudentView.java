
public class StudentView {
	public void displayStudentDetails(String name,String id,float grade)
	{
		System.out.println("Student Name : "+name+"\nStudent Id : "+id+"\nStudent Grade : "+grade+"\n");
	}
}
