
public interface CustomerRepository {
	
	void findCustomerById(int id);
}
