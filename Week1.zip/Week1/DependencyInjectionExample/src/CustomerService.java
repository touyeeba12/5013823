
public class CustomerService {
	CustomerRepository custRepo;
	//dependency Injection
	CustomerService(CustomerRepository custRepo)
	{
		this.custRepo = custRepo;
	}
	void getCustomerByid(int id)
	{
		custRepo.findCustomerById(id);
	}
}
