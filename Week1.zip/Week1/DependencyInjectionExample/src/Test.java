
public class Test {
	public static void main(String args[])
	{
		CustomerRepository custRepo = new CustomerRepositoryImpl();
		CustomerService custService = new CustomerService(custRepo);
		
		custService.getCustomerByid(1);
	}
}
