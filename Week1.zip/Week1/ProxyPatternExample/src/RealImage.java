
public class RealImage implements Image {
	String fileName;
	RealImage(String fileName){
		this.fileName = fileName;
		loadImageFromServer();
	}
	void loadImageFromServer()
	{
		System.out.println("Loading Image: "+fileName);
	}
	@Override
	public void display() {
		System.out.println("Displaying Image: "+fileName);
	}
}
