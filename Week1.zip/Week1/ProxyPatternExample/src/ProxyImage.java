
public class ProxyImage implements Image {
	RealImage img;
	String fileName;
	ProxyImage(String fileName)
	{
		this.fileName = fileName;
	}
	@Override
	public void display() {
		
		if(img == null)
			img = new RealImage(fileName);
		img.display();
	}

}
