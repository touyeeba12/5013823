
public class Test {

	public static void main(String[] args) {
		String fileName = "Image1";
		
		ProxyImage img = new ProxyImage(fileName);
		img.display();
		
		img.display();

	}

}
