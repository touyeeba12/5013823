
/*Explain linear search and binary search algorithms.
 * 
 *  Linear search involves checking each element in the list sequentially until the desired element is found or the list ends.
 *  Time Complexity: O(n), where n is the number of elements in the list. 
 *  In the worst case, the search might need to examine every element.
 *  
 *   Binary search is a more efficient search algorithm that works on sorted lists.
 *   It repeatedly divides the search interval in half. 
 *   If the target value is less than the middle element, it searches the left half; otherwise, it searches the right half.
 *   Time Complexity: O(log n), where n is the number of elements in the list. This makes it much faster than linear search for large datasets.
 * */
import java.util.*;
public class LibraryManagementSystem {
	class Book{
		int bookId;
		String title;
		String author;
		public Book(int bookId, String title, String author) {
			super();
			this.bookId = bookId;
			this.title = title;
			this.author = author;
		}
		public int getBookId() {
			return bookId;
		}
		public void setBookId(int bookId) {
			this.bookId = bookId;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getAuthor() {
			return author;
		}
		public void setAuthor(String author) {
			this.author = author;
		}
		@Override
		public String toString() {
			return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + "]";
		}
	}
	public Book linearSearch(Book[]books,String title)
	{
		Book res = null;
		for(Book b : books)
		{
			if(b.getTitle().equals(title))
			{
				res = b;
			}
		}
		
		if(res == null)
			System.out.println("Book Not found");
		return  res;
	}
	public Book binarySearch(Book[]books,String title)
	{
		//searching using ProductId
		int left = 0;
        int right = books.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = books[mid].getTitle().compareToIgnoreCase(title);
            if (comparison == 0) {
                return books[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
       	System.out.println("Book Not Found");
       	return null;
    }
	public void sortBooksByTitle(Book[] books) {
		 Arrays.sort(books, 0, 5, new Comparator<Book>() {
	            @Override
	            public int compare(Book b1, Book b2) {
	                return b1.getTitle().compareToIgnoreCase(b2.getTitle());
	            }
	        });
    }
	public static void main(String args[])
	{
		LibraryManagementSystem lms = new LibraryManagementSystem();
		Book[] books = {
			lms.new Book(1, "The Great Gatsby", "F. Scott Fitzgerald"),
            lms.new Book(2, "To Kill a Mockingbird", "Harper Lee"),
            lms.new Book(3, "1984", "George Orwell"),
            lms.new Book(4, "Moby Dick", "Herman Melville"),
            lms.new Book(5, "The Catcher in the Rye", "J.D. Salinger")
		};
		
		System.out.println("Linear Search: ");
		System.out.println(lms.linearSearch(books, "To Kill a Mockingbird"));
		
		System.out.println("Binary Search: ");
		lms.sortBooksByTitle(books);
		System.out.println(lms.binarySearch(books, "The Catcher in the Rye"));
	}
}

/*Compare the time complexity of linear and binary search.
 * Linear Search: O(n) - Each element must be checked in the worst case.
 * Binary Search: O(log n) - The list is repeatedly divided in half, leading to significantly fewer comparisons.
 * 
 * 
 * Discuss when to use each algorithm based on the data set size and order.
 * Linear Search:
	Suitable for small or unsorted datasets.
	Useful when the overhead of sorting is not justified.
*Binary Search:
	Best for large, sorted datasets where the overhead of sorting can be reduced over many search operations.
	Provides much faster search times compared to linear search for large datasets.
 * */
