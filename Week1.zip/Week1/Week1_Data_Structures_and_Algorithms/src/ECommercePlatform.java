/*
Big O notation is used to describe the performance or complexity of an algorithm in terms of the size of the input data. 
It provides an upper bound on the time or space complexity, making it easier to compare the efficiency of different algorithms.


Best Case: The scenario where the algorithm performs the minimum number of operations. For search operations, 
it could be finding the element on the first try.

Average Case: The scenario representing the expected number of operations, averaged over all possible inputs.

Worst Case: The scenario where the algorithm performs the maximum number of operations. For search operations,
it could be when the element is not present in the array.

*/
public class ECommercePlatform {
	class Product
	{
		int productId;
		String productName;
		String category;
		
		public Product(int productId, String productName, String category) {
			super();
			this.productId = productId;
			this.productName = productName;
			this.category = category;
		}
		public int getProductId() {
			return productId;
		}
		public void setProductId(int productId) {
			this.productId = productId;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public String getCategory() {
			return category;
		}
		public void setCategory(String category) {
			this.category = category;
		}
		@Override
		public String toString() {
			return "Product [productId=" + productId + ", productName=" + productName + ", category=" + category + "]";
		}
	}
	static class Operations{
		public static Product linearSearch(Product[]products,int keyProductId)
		{
			Product res = null;
			//searching using ProductId
			for(Product p : products)
			{
				if(p.getProductId() == keyProductId)
				{
					res = p;
				}
			}
			
			if(res == null)
				System.out.println("Product Not found");
			return  res;
		}
		public static Product binarySearch(Product[]products,int keyProductId)
		{
			//searching using ProductId
			int left = 0;
	        int right = products.length - 1;

	        while (left <= right) {
	            int mid = left + (right - left) / 2;

	            if (products[mid].getProductId() == keyProductId) {
	                return products[mid];
	            } else if (products[mid].getProductId() < keyProductId) {
	                left = mid + 1;
	            } else {
	                right = mid - 1;
	            }
	        }
	        return null;
	    }
	}
	public static void main(String args[])
	{
		ECommercePlatform ecp = new ECommercePlatform();
		Product[] products = {
			ecp.new Product(1, "Laptop", "Electronics"),
            ecp.new Product(2, "Smartphone", "Electronics"),
            ecp.new Product(3, "Tablet", "Electronics"),
            ecp.new Product(4, "Headphones", "Accessories"),
            ecp.new Product(5, "Charger", "Accessories")
		};
		
		System.out.println("Binary Search: ");
		System.out.println(Operations.binarySearch(products, 5));
		
		System.out.println("Linear Search: ");
		System.out.println(Operations.linearSearch(products, 4));
		
		
	}
}


/*
Linear Search:
Best Case: O(1) – The product is the first element in the array.
Average Case: O(n) – On average, the product is found in the middle of the array.
Worst Case: O(n) – The product is the last element or not in the array.

Binary Search:
Best Case: O(1) – The product is the middle element of the array.
Average Case: O(log n) – On average, the product is found after log(n) comparisons.
Worst Case: O(log n) – The product is at one of the ends of the array or not in the array.


For an e-commerce platform where search performance is critical and the dataset is large, 
binary search is more suitable despite the initial sorting overhead. 
This ensures faster search operations, leading to a better user experience.
*/
