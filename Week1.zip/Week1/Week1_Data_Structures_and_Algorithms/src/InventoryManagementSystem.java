/*
 * Q1  Explain why data structures and algorithms are essential in handling large inventories.
 * Efficient data storage and retrieval are crucial for handling large inventories to ensure quick access and modifications.
 * They help in managing the complexity of operations like search, insertion, deletion, and update, ensuring that they remain optimal even with large datasets.
 * 
 * ArrayList: Good for dynamic arrays where frequent access and iteration are needed. However, insertion and deletion (other than at the end) can be costly.
 * HashMap: Excellent for quick access, insertion, and deletion operations using key-value pairs. Ideal for scenarios where unique identifiers (like productId) are used for quick lookups.
 *  */

import java.util.*;
public class InventoryManagementSystem {
	HashMap<Integer,Product>map; //hashmap is used as it is excellent for quick access, insertion, and deletion operations using key-value pairs
	class Product{
		int productId;
		String productName;
		int quantity;
		double price;
		
		public Product(int productId, String productName, int quantity, double price) {
			super();
			this.productId = productId;
			this.productName = productName;
			this.quantity = quantity;
			this.price = price;
		}
		public int getProductId() {
			return productId;
		}
		public void setProductId(int productId) {
			this.productId = productId;
		}
		public String getProductName() {
			return productName;
		}
		public void setProductName(String productName) {
			this.productName = productName;
		}
		public int getQuantity() {
			return quantity;
		}
		public void setQuantity(int quantity) {
			this.quantity = quantity;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		@Override
		public String toString() {
			return "productId=" + productId + ", productName=" + productName + ", quantity=" + quantity
					+ ", price=" + price;
		}
	}
	public class Operations{
		Operations()
		{
			map = new HashMap<>();
		}
		void addProduct(int id,Product product)
		{
			map.put(id, product);
		}
		void updateProduct(int  id,Product product)
		{
			if(map.containsKey(id))
				map.put(id, product);
			else
				System.out.println("Product not found");
		}
		void deleteProduct(int id)
		{
			if(map.containsKey(id))
				map.remove(id);
			else
				System.out.println("Product not found");
		}
		void displayAllProducts()
		{
			for(int key:map.keySet())
			{
				System.out.println(map.get(key));
			}
		}
	}
	public static void main(String[] args) {
		
		InventoryManagementSystem ims = new InventoryManagementSystem();
		
		Product product1 = ims.new Product(1, "Product 1", 10, 99.99);
        Product product2 = ims.new Product(2, "Product 2", 5, 49.99);
        Product product3 = ims.new Product(3, "Product 3", 20, 29.99);

       
        Operations op = ims.new Operations();
        op.addProduct(1, product1);
        op.addProduct(2, product2);
        op.addProduct(3, product3);
        
        System.out.println("Displaying all Products");
        op.displayAllProducts();
        
        product2.setQuantity(15);
        op.updateProduct(2, product2);
        op.deleteProduct(3);
        
        System.out.println("Displaying all Products after updation and deletion");
        op.displayAllProducts();
	}
	/*
	 * The worst-case time complexity of retrieval in HashMap is O(n) when all keys map to the same index,
	 * since here all product ids are different we will have Time Complexities as:
	 * Add Product: O(1) – HashMap allows constant-time insertion.
	 * Update Product: O(1) – HashMap allows constant-time updates.
	 * Delete Product: O(1) – HashMap allows constant-time deletions
	 * 
	 * .
	 * Memory Usage: Ensure efficient memory usage by resizing the HashMap appropriately.
	 * Concurrency: For a multi-threaded environment, consider using ConcurrentHashMap to handle concurrent modifications safely.
	 * Load Factor: Adjust the load factor of the HashMap to balance between space and time complexity. This will help maintain efficient performance as the number of entries grows.
	 * */
	

}
