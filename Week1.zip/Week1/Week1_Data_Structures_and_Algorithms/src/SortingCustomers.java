
/*
Bubble Sort: A simple comparison-based algorithm where each pair of adjacent elements is compared, and they are swapped if they are in the wrong order. 
This process is repeated until the list is sorted.

Insertion Sort: Builds the final sorted array one item at a time, with the array being virtually split into a sorted and an unsorted part.
 Values from the unsorted part are picked and placed at the correct position in the sorted part.

Quick Sort: A divide-and-conquer algorithm that selects a 'pivot' element from the array and partitions the other elements into two sub-arrays,
 according to whether they are less than or greater than the pivot. The sub-arrays are then sorted recursively.

Merge Sort: Also a divide-and-conquer algorithm that divides the array into two halves, sorts them, and then merges them back together. 
It is stable and works well with large datasets.
*/
public class SortingCustomers {
	
	class Order{
		int orderId;
		String customerName;
		double totalPrice;
		
		public Order(int orderId, String customerName, double totalPrice) {
			super();
			this.orderId = orderId;
			this.customerName = customerName;
			this.totalPrice = totalPrice;
		}
		public int getOrderId() {
			return orderId;
		}
		public void setOrderId(int orderId) {
			this.orderId = orderId;
		}
		public String getCustomerName() {
			return customerName;
		}
		public void setCustomerName(String customerName) {
			this.customerName = customerName;
		}
		public double getTotalPrice() {
			return totalPrice;
		}
		public void setTotalPrice(double totalPrice) {
			this.totalPrice = totalPrice;
		}
		@Override
		public String toString() {
			return "Order [orderId=" + orderId + ", customerName=" + customerName + ", totalPrice=" + totalPrice + "]";
		}
	}
	static class SortingAlgos{
		static void bubbleSort(Order orders[]) {
			int n = orders.length;
			for(int i = 0;i<n-1;i++)
			{
				for(int j = 0;j<n-i-1;j++)
				{
					if(orders[j].getTotalPrice() > orders[j+1].getTotalPrice())
					{
						Order temp = orders[j];
						orders[j] = orders[j+1];
						orders[j+1] = temp;
					}
				}
			}
		}
		static void quickSort(Order[] orders,int low, int high) {
		  if (low < high) {
	            int pi = partition(orders, low, high);
	            quickSort(orders, low, pi - 1);
	            quickSort(orders, pi + 1, high);
	        }
		
		}
		private static int partition(Order[] orders, int low, int high) {
	        double pivot = orders[high].getTotalPrice();
	        int i = (low - 1);
	        for (int j = low; j < high; j++) {
	            if (orders[j].getTotalPrice() <= pivot) {
	                i++;
	               
	                Order temp = orders[i];
	                orders[i] = orders[j];
	                orders[j] = temp;
	            }
	        }
	        Order temp = orders[i + 1];
	        orders[i + 1] = orders[high];
	        orders[high] = temp;

	        return i + 1;
	    }
	}
	public static void main(String[] args) {
		SortingCustomers sc = new SortingCustomers();
		 Order[] orders = {
		            sc.new Order(1, "Alice", 300.00),
		            sc.new Order(2, "Bob", 150.00),
		            sc.new Order(3, "Charlie", 500.00),
		            sc.new Order(4, "David", 200.00),
		            sc.new Order(5, "Eve", 400.00)
		        };
        System.out.println("Bubble Sort:");
        SortingAlgos.bubbleSort(orders);
        for (Order order : orders) {
            System.out.println(order);
        }
        Order[] orders1 = {
	            sc.new Order(1, "Alice", 300.00),
	            sc.new Order(2, "Bob", 150.00),
	            sc.new Order(3, "Charlie", 500.00),
	            sc.new Order(4, "David", 200.00),
	            sc.new Order(5, "Eve", 400.00)
		        };
	    System.out.println("Quick Sort:");
	    SortingAlgos.quickSort(orders1,0,orders1.length-1);
	    for (Order order : orders1) {
	        System.out.println(order);
	    }
	}

}
/*
Bubble Sort:
Best Case: O(n) (when the array is already sorted)
Average Case: O(n^2)
Worst Case: O(n^2)

Bubble Sort is simple but inefficient for large datasets due to its quadratic time complexity in average and worst cases.


Quick Sort:
Best Case: O(nlog n)
Average Case: O(nlog n)
Worst Case: O(n^2) (when the pivot is the smallest or largest element)

Quick Sort is generally preferred for large datasets due to its average-case time complexity of O(n log n). 
Despite the potential for worst-case performance,
it is often faster than Bubble Sort and other O(n^2) algorithms in practice, especially with good pivot selection strategies.*/
