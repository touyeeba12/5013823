/*
Contiguous Memory Allocation: Arrays are stored in contiguous memory locations, meaning each element is placed directly next to its neighbors.
Indexing: Arrays provide direct access to any element using an index, which makes accessing elements very fast (O(1) time complexity).
Fixed Size: Once an array is created, its size cannot be changed. This means that the memory allocation is fixed and cannot grow or shrink dynamically.

Fast Access: Direct indexing allows constant time (O(1)) access to elements.
Memory Efficiency: Arrays are memory efficient for storing data as they don't require additional pointers or references.
Cache Friendly: Contiguous memory allocation makes arrays cache-friendly, leading to faster access times.

*/
public class EmployeeManagementSystem {
	private Employee[] employees;
	private int size;
	private int capacity;
	EmployeeManagementSystem(int capacity)
	{
		this.capacity = capacity;
		size = 0;
		employees= new Employee[capacity];
	}
	void add(Employee employee)
	{
		if(size == capacity)
		{
			System.out.println("Array is Full");
		}
		else {
			employees[size] = employee;
			size++;
		}
	}
	Employee search(int employeeId)
	{
		for(Employee emp : employees)
		{
			if(employeeId == emp.getEmployeeId())
			{
				return emp;
			}
		}
		System.out.println("Employee Not Found");
		return null;
	}
	void traverse()
	{
		for(int i = 0;i<size;i++)
		{
			System.out.println(employees[i]);
		}
	}
	void delete(int employeeId)
	{
		int idx = -1;
		for(int i = 0;i<size;i++)
		{
			if(employees[i].getEmployeeId() == employeeId)
			{
				idx = i;
				break;
			}
		}
		if(idx == -1)
		{
			System.out.println("Employee Not found");
		}
		else {
			for(int i = idx+1;i<size;i++)
			{
				employees[i-1] = employees[i];
			}
			size--;
		}
	}
	class Employee{
		int employeeId;
		String name;
		String position;
		long salary;
		
		public Employee(int employeeId, String name, String position, long salary) {
			super();
			this.employeeId = employeeId;
			this.name = name;
			this.position = position;
			this.salary = salary;
		}
		
		public int getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getPosition() {
			return position;
		}

		public void setPosition(String position) {
			this.position = position;
		}

		public long getSalary() {
			return salary;
		}

		public void setSalary(long salary) {
			this.salary = salary;
		}

		@Override
		public String toString() {
			return "Employee [employeeId=" + employeeId + ", name=" + name + ", position=" + position + ", salary="
					+ salary + "]";
		}
	}
	public static void main(String args[])
	{
		EmployeeManagementSystem ems = new EmployeeManagementSystem(10);
		ems.add(ems.new Employee(1, "Alice", "Manager", 70000));
	    ems.add(ems.new Employee(2, "Bob", "Developer", 60000));
	    ems.add(ems.new Employee(3, "Charlie", "Designer", 50000));
	    
	    System.out.println("Traversal");
	    ems.traverse();
	    
	    System.out.println("Searching employee with Id 3");
	    System.out.println(ems.search(3));
	    
	    ems.delete(2);
	    
	    System.out.println("Traversal after Deletion");
	    ems.traverse();
	}
	 
}

/*
Add: O(1) - Adding an element to the array is a constant-time operation unless the array is full.
Search: O(n) - In the worst case, we may need to traverse the entire array to find an element.
Traverse: O(n) - Traversing the entire array requires linear time.
Delete: O(n) - First we have to search the element and we have to delete the element and shift all other elements accordingly.

Limitations:
Fixed Size: Arrays have a fixed size, which limits their flexibility. 
Inefficient Deletion and Insertion: Deleting or inserting an element (other than at the end) requires shifting elements, leading to O(n) time complexity.

Use arrays when the size of the data is known in advance and doesn't change frequently.
Arrays are suitable for applications where fast access to elements is required, and the operations predominantly involve accessing elements by index.

*/
