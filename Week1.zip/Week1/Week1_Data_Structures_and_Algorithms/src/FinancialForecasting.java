/*
 * Explain the concept of recursion and how it can simplify certain problems.
 * Recursion: A method where the solution to a problem depends on solutions to smaller instances of the same problem. A recursive function calls itself with a subset of the original problem until it reaches a base case.
 * Advantages: Simplifies complex problems by breaking them down into more manageable subproblems.
 * */
public class FinancialForecasting {
	public static double calculateFutureValue(double initialValue,double growthRate,int years)
	{
		if(years == 0)
		{
			return initialValue;
		}
		return calculateFutureValue(initialValue*(1+growthRate),growthRate,years-1);
		
	}
	public static void main(String args[])
	{
		double initialValue = 1000;
		double growthRate = 0.05;
		int years = 10;
		System.out.println("Future Value after "+years+" years");
		System.out.println(calculateFutureValue(initialValue,growthRate,years));
	}
}

/*
 * Discuss the time complexity of your recursive algorithm.
 * 
 * The time complexity of the recursive algorithm is O(n)where n is the number of years.
 * This is because the method makes a recursive call for each year until it reaches the base case.
 * 
 * 
 * Explain how to optimize the recursive solution to avoid excessive computation.
 * 
 * To avoid excessive computation, we can optimize the recursive solution using memoization. 
 * Memoization stores the results of expensive function calls and reuses them when the same inputs occur again.
*/