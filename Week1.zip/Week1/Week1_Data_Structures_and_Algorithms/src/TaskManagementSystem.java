/*Singly Linked List: Each node contains data and a reference (or pointer) to the next node in the sequence. Traversal is possible only in one direction.
Doubly Linked List: Each node contains data and two references: one to the next node and one to the previous node. This allows traversal in both directions (forward and backward).
*/
public class TaskManagementSystem {
	class Task{
		int taskId;
		String taskName;
		String status;
		public Task(int taskId, String taskName, String status) {
			super();
			this.taskId = taskId;
			this.taskName = taskName;
			this.status = status;
		}
		
		public int getTaskId() {
			return taskId;
		}

		public void setTaskId(int taskId) {
			this.taskId = taskId;
		}

		public String getTaskName() {
			return taskName;
		}

		public void setTaskName(String taskName) {
			this.taskName = taskName;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		@Override
		public String toString() {
			return "Task [taskId=" + taskId + ", taskName=" + taskName + ", status=" + status + "]";
		}
	}
	class Node{
		Task data;
		Node next;
		Node(Task data)
		{
			this.data = data;
			this.next = null;
		}
	}
	private Node head = null;
	public void addTask(Task task) {
        Node newNode = new Node(task);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }
	public Task searchTask(int taskId) {
        Node temp = head;
        while (temp != null) {
            if (temp.data.getTaskId() == taskId) {
                return temp.data;
            }
            temp = temp.next;
        }
       System.out.println("Task Not Found");
       return null;
    }
   public void traverseTasks() {
        Node temp = head;
        while (temp != null) {
            System.out.println(temp.data);
            temp = temp.next;
        }
    }
   public void deleteTask(int taskId)
   {
	   if(head == null)
	   {
		   System.out.println("Task List is Empty");
	   }
	   else if(head.data.getTaskId() == taskId)
	   {
		   head = head.next;
	   }
	   else {
		   Node temp = head;
		   while(temp.next!=null && temp.next.data.getTaskId() != taskId)
		   {
			   temp = temp.next;
		   }
		   if(temp.next == null)
		   {
			   System.out.println("Task Not Found");
		   }
		   else {
			   temp.next = temp.next.next;
		   }
	   }
   }
   public static void main(String args[])
   {
	   TaskManagementSystem tms = new TaskManagementSystem();
       
       tms.addTask(tms.new Task(1, "Design Module", "In Progress"));
       tms.addTask(tms.new Task(2, "Implement Module", "Pending"));
       tms.addTask(tms.new Task(3, "Test Module", "Completed"));
       
       System.out.println("Traversing Tasks");
       tms.traverseTasks();
       System.out.println();
       
       
       System.out.println("Searching for the task with taskId: 2");
       System.out.println(tms.searchTask(2));
       System.out.println();
       
       tms.deleteTask(3);
       System.out.println("Traversing tasks  after deleting");
       tms.traverseTasks();
       System.out.println();
   }
}

/*
Add: O(n) - Adding a task requires traversing to the end of the list to append the new task.
Search: O(n) - Searching for a task may require traversing the entire list.
Traverse: O(n) - Traversing the list involves visiting each node once.
Delete: O(n) - Deleting a task requires searching for the task, and then updating the pointers.


Dynamic Size: Linked lists can grow and shrink dynamically as elements are added or removed. 
There's no need to define an initial size.
Memory Utilization: Linked lists do not allocate memory in advance.
Memory is allocated as needed, which can be more efficient for applications with unpredictable sizes.


*/
