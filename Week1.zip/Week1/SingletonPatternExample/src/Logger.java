
public class Logger {
	private static Logger obj = new Logger();
	private Logger(){
		//To test, since the object is created only once the below line will be printed only once
		System.out.println("Object Created");
	}
	public static Logger getInstance()
	{
		return obj;
	}
}
