package com.BookStore.BookStoreAPI.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;


@Data
public class BookDTO {

	
	private long id;
	
	@NotBlank(message = "Title is mandatory")
	@Size(max = 255, message = "Title must be less than 255 characters")
	private String title;
	
	@NotBlank(message = "Author is mandatory")
	@Size(max = 255, message = "Author must be less than 255 characters")
	private String author;
	
	@NotNull(message = "Price is mandatory")
	private double price;
	
	@NotBlank(message = "ISBN is mandatory")
	@Size(max = 13, message = "ISBN must be 13 characters")
	private String isbn;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	
	
}
