package com.BookStore.BookStoreAPI.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

import com.BookStore.BookStoreAPI.exception.ResourceNotFoundException;
import com.BookStore.BookStoreAPI.model.Customer;
import com.BookStore.BookStoreAPI.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	CustomerRepository custRepository;
	
	
	public Customer createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return ((CrudRepository<Customer, Long>) custRepository).save(customer);
	}
	
	
	public Customer getCustomerById(Long id)
	{
		  return custRepository.findById(id)
	                .orElseThrow(() -> new ResourceNotFoundException("Customer not found"));
	}


	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return custRepository.findAll();
	}


	public Customer updateCustomer(Long id, Customer customer) {
		// TODO Auto-generated method stub
		Customer existingCustomer = getCustomerById(id);
        existingCustomer.setName(customer.getName());
        existingCustomer.setEmail(customer.getEmail());
        existingCustomer.setPassword(customer.getPassword());
        return custRepository.save(existingCustomer);
	}


	public void deleteCustomer(Long id) {
		// TODO Auto-generated method stub
		
		Customer customer = getCustomerById(id);
		custRepository.delete(customer);
		
	}
	
	

}
