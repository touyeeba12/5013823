package com.BookStore.BookStoreAPI.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.BookStore.BookStoreAPI.dto.CustomerDTO;
import com.BookStore.BookStoreAPI.mapper.CustomerMapper;
import com.BookStore.BookStoreAPI.model.Customer;
import com.BookStore.BookStoreAPI.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	CustomerService service;
	
	@PostMapping
	public ResponseEntity<CustomerDTO> createCustomer(@Valid @RequestBody CustomerDTO customerDTO) {
		
		
		Customer customer = CustomerMapper.INSTANCE.toEntity(customerDTO);
        Customer createdCustomer = service.createCustomer(customer);
        return ResponseEntity.ok(CustomerMapper.INSTANCE.toDTO(createdCustomer));
    }
	
 	@GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable Long id) {
        Customer customer = service.getCustomerById(id);
        return ResponseEntity.ok(CustomerMapper.INSTANCE.toDTO(customer));
    }

    @GetMapping
    public List<Customer> getAllCustomers() {
        List<Customer> customers = service.getAllCustomers();
        return customers;
        
    }

    @PutMapping("/{id}")
    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable Long id, @Valid @RequestBody CustomerDTO customerDTO) {
        Customer customer = CustomerMapper.INSTANCE.toEntity(customerDTO);
        Customer updatedCustomer = service.updateCustomer(id, customer);
        return ResponseEntity.ok(CustomerMapper.INSTANCE.toDTO(updatedCustomer));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        service.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
	/*
	 * @PostMapping("/register") public ResponseEntity<Customer> registerCustomer(
	 * 
	 * @RequestParam String name,
	 * 
	 * @RequestParam String email,
	 * 
	 * @RequestParam String password) {
	 * 
	 * Customer customer = new Customer(); customer.setName(name);
	 * customer.setEmail(email); customer.setPassword(password);
	 * 
	 * Customer createdCustomer = service.createCustomer(customer);
	 * 
	 * return ResponseEntity.ok(createdCustomer); }
	 */

}
