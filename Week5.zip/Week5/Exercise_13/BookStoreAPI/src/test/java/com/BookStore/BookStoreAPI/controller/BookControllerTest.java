package com.BookStore.BookStoreAPI.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Optional;


import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import  static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.BookStore.BookStoreAPI.Controller.BookController;
import com.BookStore.BookStoreAPI.model.Book;
import com.BookStore.BookStoreAPI.service.BookService;

@WebMvcTest(BookController.class)
public class BookControllerTest {

	 	@Autowired
	    private MockMvc mockMvc;

	    @MockBean
	    private BookService bookService;

	    private Book book;

	    @BeforeEach
	    public void setup() {
	        book = new Book(1L, "Test Book", "Author", 100.0,"isbn number");
	    }

	    @Test
	    public void testGetAllBooks() throws Exception {
	        when(bookService.getAllBooks()).thenReturn(Arrays.asList(book));

	        mockMvc.perform(get("/books"))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$[0].title").value("Test Book"));
	    }

	    @Test
	    public void testGetBookById() throws Exception {
	        when(bookService.getBookById(1L)).thenReturn(book);

	        mockMvc.perform(get("/books/1"))
	                .andExpect(status().isOk())
	                .andExpect(jsonPath("$.title").value("Test Book"));
	    }
	    @Test
	    public void testCreateBook() throws Exception {
	        Book book = new Book(1L, "Test Book", "Test Author", 29.99, "1234567890");
	        
	        when(bookService.createBook(any(Book.class))).thenReturn(book);

	        mockMvc.perform(post("/books")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content("{\"title\":\"Test Book\",\"author\":\"Test Author\",\"price\":29.99,\"isbn\":\"1234567890\"}"))
	                .andExpect(status().isCreated())
	                .andExpect(header().string("X-Custom-Header", "Book Created Successfully"))
	                .andExpect(jsonPath("$.title").value("Test Book"));
	    }
	    	
	    
	    @Test
	    public void testUpdateBook() throws Exception {
	        Book book = new Book(1L, "Updated Book", "Updated Author", 39.99, "0987654321");

	        when(bookService.updateBook(eq(1L), any(Book.class))).thenReturn(book);

	        mockMvc.perform(put("/books/1")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content("{\"title\":\"Updated Book\",\"author\":\"Updated Author\",\"price\":39.99,\"isbn\":\"0987654321\"}"))
	                .andExpect(status().isNoContent())
	                .andExpect(header().string("X-Custom-Header", "Book Updated Successfully"));
	    }

	   

	   

	    @Test
	    public void testDeleteBook() throws Exception {
	        mockMvc.perform(delete("/books/1"))
	                .andExpect(status().isNoContent());
	    }
}
