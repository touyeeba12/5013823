package com.BookStore.BookStoreAPI.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BookStore.BookStoreAPI.model.Book;
import com.BookStore.BookStoreAPI.repository.BookRepository;


@Service
public class BookService {
	
	@Autowired
	BookRepository repository;

	public List<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	public Book createBook(Book book) {
		// TODO Auto-generated method stub
		
		return repository.save(book);
		
	}

	public Book updateBook(Long id, Book bookDetails) {
        if(repository.findById(id) == null)
        	return null;
        else {
        	Book book = repository.findById(id).get();
        	 book.setTitle(bookDetails.getTitle());
             book.setAuthor(bookDetails.getAuthor());
             book.setPrice(bookDetails.getPrice());
             book.setIsbn(bookDetails.getIsbn());
        	return repository.save(book);
        }
    }
	public void deleteBook(Long id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

	public  Book getBookById(Long id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}
	
	public List<Book> getBooksByTitle(String title){
		return repository.findByTitleContainingIgnoreCase(title);
	}

	
	public List<Book> getBooksByAuthor(String author)
	{
		return repository.findByAuthorContainingIgnoreCase(author);
	}
}
